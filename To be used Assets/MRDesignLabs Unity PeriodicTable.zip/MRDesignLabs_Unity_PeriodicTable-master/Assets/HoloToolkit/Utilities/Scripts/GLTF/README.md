# UnityGLTF
Unity3D library for exporting, loading, parsing, and rendering assets stored in the [GLTF 2.0](https://github.com/KhronosGroup/glTF/tree/2.0) file format at runtime.

This snapshot comes from https://github.com/AltspaceVR/UnityGLTF/tree/26834573636a482ce9deaaabdc8fdcb094c295a8.